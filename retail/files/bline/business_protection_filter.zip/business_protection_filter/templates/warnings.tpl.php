<div class="field  pt-5 field-name-field-basic-web-page-warning field-type-text field-label-hidden">
    <div class="field-items">
        <div class="field-item even">Warning: The information provided is based on our understanding of current legislation and Revenue practice.</div>
        <div class="field-item odd">Warning: In all cases we would recommend that business owners obtain professional legal and tax advice to ensure that any arrangement put in place is appropriate to their personal and corporate circumstances.</div>
    </div>
</div>
